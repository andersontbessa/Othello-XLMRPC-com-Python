from xmlrpc.client import ServerProxy, Fault, ProtocolError
import tkinter as tk
from threading import Thread
import threading
import time
"""Função para criar conexão segura com o servidor"""
def conectar_servidor():
    while True:
        try:
            return ServerProxy("http://127.0.0.1:65432/")
        except Exception as e:
            print(f"Erro ao conectar ao servidor: {e}")
            time.sleep(2)

"""conexão com o servidor"""
server = conectar_servidor()
cor_jogador = None

while cor_jogador is None:
    try:
        cor_jogador = server.conectar()
        if cor_jogador is None:
            print("Jogo cheio! Não foi possível conectar.")
            exit()
    except Exception as e:
        print(f"Erro ao conectar ao servidor: {e}")
        server = conectar_servidor()

"""variáveis globais"""
tabuleiro = []
turno_atual = None
jogo_encerrado = False
vencedor = None
chat_mensagens = []
lock = threading.Lock()

"""funções de comunicação com o servidor"""
def atualizar_estado():
    global tabuleiro, turno_atual, jogo_encerrado, vencedor, chat_mensagens
    try:
        estado = server.get_estado()
        with lock:
            tabuleiro = estado["tabuleiro"]
            turno_atual = estado["turno"]
            jogo_encerrado = estado["jogo_encerrado"]
            vencedor = estado["vencedor"]
            chat_mensagens = server.get_chat()
    except (Fault, ProtocolError) as e:
        print(f"Erro ao atualizar estado: {e}")

def enviar_jogada(linha, coluna):
    global turno_atual
    try:
        if turno_atual != cor_jogador or jogo_encerrado:
            return
        if server.aplicar_jogada(linha, coluna, cor_jogador):
            atualizar_estado()
    except (Fault, ProtocolError) as e:
        print(f"Erro ao enviar jogada: {e}")

def enviar_mensagem():
    mensagem = entrada_chat.get()
    if mensagem:
        try:
            server.enviar_mensagem(cor_jogador, mensagem)
            entrada_chat.delete(0, tk.END)
        except (Fault, ProtocolError) as e:
            print(f"Erro ao enviar mensagem: {e}")

def desistir_jogo():
    try:
        server.desistir(cor_jogador)
    except (Fault, ProtocolError) as e:
        print(f"Erro ao desistir do jogo: {e}")
    janela.destroy()

def ao_fechar():
    try:
        server.registrar_desistencia(cor_jogador)
    except (Fault, ProtocolError) as e:
        print(f"Erro ao registrar desistência: {e}")
    janela.destroy()

"""função para atualizar a interface"""
def atualizar_interface():
    while True:
        try:
            atualizar_estado()
            with lock:
                for i in range(8):
                    for j in range(8):
                        if tabuleiro[i][j] == 1:
                            botoes[i][j].config(bg="#000000", state="disabled")
                        elif tabuleiro[i][j] == 2:
                            botoes[i][j].config(bg="#FFFFFF", state="disabled")

                if jogo_encerrado:
                    resultado = (
                        "Empate!"
                        if vencedor is None
                        else "Você venceu!" if vencedor == cor_jogador else "Você perdeu!"
                    )
                    cor_texto = "#32CD32" if vencedor == cor_jogador else "#FF4500"
                    label_turno.config(text=resultado, fg=cor_texto)
                else:
                    label_turno.config(
                        text=f"É a sua vez!" if turno_atual == cor_jogador else "Aguarde sua vez!",
                        fg="#32CD32" if turno_atual == cor_jogador else "#FF4500"
                    )

                pontuacao_preto = sum(linha.count(1) for linha in tabuleiro)
                pontuacao_branco = sum(linha.count(2) for linha in tabuleiro)
                label_pontuacao.config(
                    text=f"Pontos - Preto: {pontuacao_preto} | Branco: {pontuacao_branco}",
                    fg="#FFD700"
                )

                chat_texto.config(state=tk.NORMAL)
                chat_texto.delete(1.0, tk.END)
                for cor, mensagem in chat_mensagens:
                    remetente = "Preto" if cor == 1 else "Branco"
                    chat_texto.insert(
                        tk.END,
                        f"{remetente}: {mensagem}\n",
                        "preto" if cor == 1 else "branco"
                    )
                chat_texto.config(state=tk.DISABLED)
            time.sleep(1)
        except Exception as e:
            print(f"Erro ao atualizar interface: {e}")

"""interface gráfica"""
janela = tk.Tk()
janela.title("Othello Game - Cliente")
janela.configure(bg="#2C2F33")
janela.protocol("WM_DELETE_WINDOW", ao_fechar)

"""estilo"""
estilo_botao = {"width": 4, "height": 2, "font": ("Arial", 12), "bg": "#7289DA", "fg": "#FFFFFF"}
estilo_label = {"font": ("Arial", 14), "bg": "#2C2F33", "fg": "#FFFFFF"}

"""titulo"""
label_titulo = tk.Label(janela, text="Othello Game", font=("Arial Black", 24), bg="#2C2F33", fg="#FF6347")
label_titulo.pack(pady=10)

frame_tabuleiro = tk.Frame(janela, bg="#2C2F33")
frame_tabuleiro.pack(side=tk.LEFT, padx=20, pady=20)

botoes = [[None for _ in range(8)] for _ in range(8)]
for i in range(8):
    for j in range(8):
        botoes[i][j] = tk.Button(frame_tabuleiro, **estilo_botao, command=lambda r=i, c=j: enviar_jogada(r, c))
        botoes[i][j].grid(row=i, column=j, padx=2, pady=2)

frame_info = tk.Frame(janela, bg="#2C2F33")
frame_info.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

label_cor_jogador = tk.Label(
    frame_info,
    text=f"{'Preto' if cor_jogador == 1 else 'Branco'}",
    **estilo_label
)
label_cor_jogador.pack(pady=10)

label_turno = tk.Label(frame_info, text="", **estilo_label)
label_turno.pack(pady=10)

label_pontuacao = tk.Label(frame_info, text="Pontos - Preto: 0 | Branco: 0", **estilo_label)
label_pontuacao.pack(pady=10)

frame_chat = tk.Frame(frame_info, bg="#2C2F33")
frame_chat.pack(fill=tk.BOTH, expand=True, pady=10)

chat_texto = tk.Text(frame_chat, height=15, state=tk.DISABLED, wrap=tk.WORD, bg="#23272A", fg="#FFFFFF", font=("Arial", 12))
chat_texto.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

barra_rolagem = tk.Scrollbar(frame_chat, command=chat_texto.yview, bg="#2C2F33")
barra_rolagem.pack(side=tk.RIGHT, fill=tk.Y)
chat_texto.config(yscrollcommand=barra_rolagem.set)

entrada_chat = tk.Entry(frame_info, bg="#99AAB5", fg="#2C2F33", font=("Arial", 12))
entrada_chat.pack(fill=tk.X, padx=5, pady=5)

botao_enviar = tk.Button(frame_info, text="Enviar Mensagem", command=enviar_mensagem, bg="#7289DA", fg="#FFFFFF")
botao_enviar.pack(pady=5)

botao_desistir = tk.Button(frame_info, text="Desistir", command=desistir_jogo, bg="#FF6347", fg="#FFFFFF")
botao_desistir.pack(pady=10)

"""atualizar interface"""
Thread(target=atualizar_interface, daemon=True).start()

janela.mainloop()
