from xmlrpc.server import SimpleXMLRPCServer
import threading

"""constantes"""
VAZIO, PRETO, BRANCO = 0, 1, 2
DIRECOES = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]

"""inicializar tabuleiro e estado"""
tabuleiro = [[VAZIO] * 8 for _ in range(8)]
tabuleiro[3][3], tabuleiro[4][4] = BRANCO, BRANCO
tabuleiro[3][4], tabuleiro[4][3] = PRETO, PRETO
turno_atual = PRETO
jogadores = []
jogo_encerrado = False
vencedor = None
chat = []
lock = threading.Lock()

def log_mensagem(mensagem):
    """Exibe uma mensagem de log formatada."""
    print(f"[LOG] {mensagem}")

def alternar_turno():
    global turno_atual
    turno_atual = PRETO if turno_atual == BRANCO else BRANCO
    log_mensagem(f"Turno alternado. Agora é a vez do jogador {'Preto' if turno_atual == PRETO else 'Branco'}.")

def jogada_valida(linha, coluna, cor):
    if tabuleiro[linha][coluna] != VAZIO:
        return False
    outra_cor = BRANCO if cor == PRETO else PRETO
    for dx, dy in DIRECOES:
        x, y = linha + dx, coluna + dy
        encontrou_oponente = False
        while 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == outra_cor:
            encontrou_oponente = True
            x += dx
            y += dy
        if encontrou_oponente and 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == cor:
            return True
    return False

def aplicar_jogada(linha, coluna, cor):
    global tabuleiro, turno_atual, jogo_encerrado, vencedor
    with lock:
        if jogo_encerrado or turno_atual != cor or not jogada_valida(linha, coluna, cor):
            log_mensagem(f"Jogada inválida: ({linha}, {coluna}) pelo jogador {'Preto' if cor == PRETO else 'Branco'}.")
            return False

        tabuleiro[linha][coluna] = cor
        log_mensagem(f"Jogada aplicada: ({linha}, {coluna}) pelo jogador {'Preto' if cor == PRETO else 'Branco'}.")

        outra_cor = BRANCO if cor == PRETO else PRETO
        for dx, dy in DIRECOES:
            x, y = linha + dx, coluna + dy
            caminho = []
            while 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == outra_cor:
                caminho.append((x, y))
                x += dx
                y += dy
            if 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == cor:
                for cx, cy in caminho:
                    tabuleiro[cx][cy] = cor
                log_mensagem(f"Peças convertidas: {caminho}")

        alternar_turno()

        """verificar se o próximo jogador tem jogadas válidas"""
        if not any(jogada_valida(i, j, turno_atual) for i in range(8) for j in range(8)):
            alternar_turno()
            if not any(jogada_valida(i, j, turno_atual) for i in range(8) for j in range(8)):
                verificar_fim_de_jogo()

        return True

def verificar_fim_de_jogo():
    global jogo_encerrado, vencedor
    if all(all(celula != VAZIO for celula in linha) for linha in tabuleiro):
        jogo_encerrado = True
    elif not any(jogada_valida(i, j, turno_atual) for i in range(8) for j in range(8)):
        jogo_encerrado = True

    if jogo_encerrado:
        contar_pecas()
        log_mensagem("Jogo encerrado.")

def contar_pecas():
    global vencedor
    contagem_preto = sum(linha.count(PRETO) for linha in tabuleiro)
    contagem_branco = sum(linha.count(BRANCO) for linha in tabuleiro)
    log_mensagem(f"Contagem de peças - Preto: {contagem_preto}, Branco: {contagem_branco}.")
    if contagem_preto > contagem_branco:
        vencedor = PRETO
        log_mensagem("Jogador Preto venceu!")
    elif contagem_branco > contagem_preto:
        vencedor = BRANCO
        log_mensagem("Jogador Branco venceu!")
    else:
        vencedor = None
        log_mensagem("O jogo terminou em empate.")

def conectar():
    with lock:
        if len(jogadores) < 2:
            cor = PRETO if len(jogadores) == 0 else BRANCO
            jogadores.append(cor)
            log_mensagem(f"Jogador {'Preto' if cor == PRETO else 'Branco'} conectado.")
            return cor
        log_mensagem("Tentativa de conexão recusada: Jogo cheio.")
        return None

def get_estado():
    with lock:
        estado = {
            "tabuleiro": tabuleiro,
            "turno": turno_atual,
            "jogo_encerrado": jogo_encerrado,
            "vencedor": vencedor,
            "pontuacao": {
                "preto": sum(linha.count(PRETO) for linha in tabuleiro),
                "branco": sum(linha.count(BRANCO) for linha in tabuleiro),
            },
        }
        return estado

def desistir(cor):
    global jogo_encerrado, vencedor
    with lock:
        if cor in jogadores:
            jogo_encerrado = True
            vencedor = BRANCO if cor == PRETO else PRETO
            log_mensagem(f"Jogador {'Preto' if cor == PRETO else 'Branco'} desistiu. Vencedor: {'Preto' if vencedor == PRETO else 'Branco'}.")
            return vencedor
    return None

def enviar_mensagem(cor, mensagem):
    with lock:
        chat.append((cor, mensagem))
        if len(chat) > 50:
            chat.pop(0)
        remetente = "Preto" if cor == PRETO else "Branco"
        log_mensagem(f"Mensagem enviada por {remetente}: {mensagem}")

def get_chat():
    with lock:
        return chat

"""iniciar servidor"""
servidor = SimpleXMLRPCServer(("127.0.0.1", 65432), allow_none=True)
servidor.register_function(conectar, "conectar")
servidor.register_function(get_estado, "get_estado")
servidor.register_function(aplicar_jogada, "aplicar_jogada")
servidor.register_function(desistir, "desistir")
servidor.register_function(enviar_mensagem, "enviar_mensagem")
servidor.register_function(get_chat, "get_chat")

log_mensagem("Servidor RPC iniciado na porta 65432...")
servidor.serve_forever()
